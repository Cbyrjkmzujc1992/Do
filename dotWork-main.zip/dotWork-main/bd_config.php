<?php
return [
    'bd_name'=> 'users',
    'bd_host' => 'localhost',
    'bd_user' => 'root',
    'bd_pass' => ''
];
?>